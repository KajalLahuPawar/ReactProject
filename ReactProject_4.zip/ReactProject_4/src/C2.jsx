import React from "react";

const C2=()=>{
    return(
        <>
          <img src="images/contact1.jpeg" className="img-fluid w-100 h-100" alt="" />
        </>
    )
}

export default C2;